import { Injectable } from '@angular/core';
import { ProductModel } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: ProductModel[];


  constructor() {
    this.products = [
        { id: 'p01', name: 'name 1', price: 100, photo: 'thumb1.gif' },
        { id: 'p02', name: 'name 2', price: 200, photo: 'thumb2.gif' },
        { id: 'p03', name: 'name 3', price: 300, photo: 'thumb3.gif' },
        { id: 'p04', name: 'name 4', price: 400, photo: 'thumb4.gif' },
        { id: 'p05', name: 'name 5', price: 500, photo: 'thumb5.gif' },
        { id: 'p06', name: 'name 6', price: 600, photo: 'thumb6.gif' },
        { id: 'p07', name: 'name 7', price: 700, photo: 'thumb7.gif' }
    ];
}

findAll(): ProductModel[] {
  return this.products;
}

find(id: string): ProductModel {
  return this.products[this.getSelectedIndex(id)];
}

private getSelectedIndex(id: string) {
  for (var i = 0; i < this.products.length; i++) {
      if (this.products[i].id == id) {
          return i;
      }
  }
  return -1;
}
}
