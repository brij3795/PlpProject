import { Component, OnInit } from '@angular/core';
import { ProductModel } from '../model/product';
import { ProductService } from '../service/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
   products: ProductModel[];

  constructor(private productService: ProductService, private routes: Router) {
    
   }
  ngOnInit() {
    this.products = this.productService.findAll();
  }

}
