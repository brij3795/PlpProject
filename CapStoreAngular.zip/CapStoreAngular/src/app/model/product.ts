export class ProductModel {

    id: string;
    name: string;
    price: number;
    photo: string;

}