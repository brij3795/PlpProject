import { ProductModel } from './product';

export class Item {

    product: ProductModel;
    quantity: number;

}